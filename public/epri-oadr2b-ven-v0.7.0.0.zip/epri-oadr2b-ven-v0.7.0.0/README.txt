*
* Copyright (c) 2013, Electric Power Research Institute (EPRI)
* All rights reserved.
*

This zip file is a binary release of the EPRI OpenADR2.0b pull VEN.
The .exe extension was stripped from the executable in to allow the
zip file to be sent through GMail without being rejected.  Before
the executable oadr2b-ven can be run, .exe must be appended to the 
file.

This software is released under the BSD-3-Clause license.  See
LICENSE.txt for more informaiton.

This software is released under both binary and source forms.
See the following sourforge page for links to other downloads:

  * http://sourceforge.net/projects/openadr2bven-pull/?source=navbar

A VTN implementation is also available on sourceforge:

  * http://sourceforge.net/projects/openadr2vtn/?source=navbar